from django.apps import AppConfig

class FashionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fashion'
    def ready(self):
        import fashion.signals